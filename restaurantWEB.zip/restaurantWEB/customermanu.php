<img src="images/prof.png" class="img-thumbnail img-circle">
		<a href="index.php?id=restaurantlist"><span class="glyphicon glyphicon-home"></span> Home</a>
		<a href="index.php?id=viewOrder"><span class="glyphicon glyphicon-pencil"></span> View Order</a>
		<a href="index.php?id=edit"><span class="glyphicon glyphicon-edit"></span> Edit Profile</a></a>