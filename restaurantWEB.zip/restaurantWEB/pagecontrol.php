<?php
//control home page

$status=$_SESSION["status"];

//control  leftcontent of the home page
if ($status==="customer") {
	$leftcontent ="customermanu.php";
} 
elseif ($status==="manager") {
	$leftcontent ="managermanu.php";
}
else {
	$leftcontent ="admin/adminmanu.php";
}


//control  rightcontent of the home page
if (isset($_GET['id'])) {
	switch ($_GET['id']) {
		case 'restaurantlist':
			$content ="restaurantlist.php";
			break;

		case 'foodMenu':
			$content="foodmenu.php";
			break;

		case 'viewOrder':
			$content="viewOrder.php";
			break;

		case 'makeOrder':
			$content="makeOrder.php";
		break;

		case 'addFoodMenu':
			$content="addFoodMenu.php";
		break;

		case 'suplierList':
			$content="suplierList.php";
		break;

		case 'addSuplier':
			$content="addSuplier.php";
		break;

		case 'registerRestaurant':
			$content="registerRestaurant.php";
		break;
		
		
		default:
	//default bage display in content
		if ($status==="manager") {
			$content ="restaurantlist.php";
			} 
			elseif ($status==="customer") {
				$content ="restaurantlist.php";
			}
			elseif ($status==="admin") {
			$content="admin/admincontent.php";
			}
			else {
				$content ="restaurantlist.php";
			}			
		break;
		}
	}
	else{

	//default bage display in content
	if ($status==="manager") {
		$content ="restaurantlist.php";
		} 
		elseif ($status==="customer") {
			$content ="restaurantlist.php";
		}
		elseif ($status==="admin") {
		$content="admin/admincontent.php";
		}
		else {
			$content ="restaurantlist.php";
		}			
		
}

  ?>