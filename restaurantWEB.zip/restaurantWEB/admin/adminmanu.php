<img src="images/prof.png" class="img-thumbnail img-circle">
		<a href="index.php?id=edit"><span class="glyphicon glyphicon-edit"></span> edit info</a></a>
		<a href="index.php?id=edit"><span class="glyphicon glyphicon-edit"></span> edit info</a></a>
		<a href="index.php?id=edit"><span class="glyphicon glyphicon-edit"></span> edit info</a></a>
		<a href="index.php?id=edit"><span class="glyphicon glyphicon-edit"></span> edit info</a></a>
		<a href="index.php?id=edit"><span class="glyphicon glyphicon-edit"></span> edit info</a></a>
		<a href="index.php?id=edit"><span class="glyphicon glyphicon-edit"></span> edit profile pichture</a></a>