<?php

$con = mysqli_connect("localhost","root","","irb");
if ($con) {

	$title="";
	$abstr="";
	$filenameNew="";
	
	//querys for search user in database
	$stdSearchAll ="SELECT * FROM students WHERE regno='$regno'";
	$dosSearchAll ="SELECT * FROM deanofstudents WHERE dosempid='$regno'";
	$drSearchAll ="SELECT * FROM director WHERE dempid='$regno'";
	$rvwSearchAll ="SELECT * FROM reviewer WHERE reviewerid='$regno'";
	$adminSearchAll ="SELECT * FROM admin WHERE empid='$regno'";

	$stdSearch ="SELECT * FROM students WHERE regno='$regno' AND password='$pass' ";
	$dosSearch ="SELECT * FROM deanofstudents WHERE dosempid='$regno' AND password='$pass' ";
	$drSearch ="SELECT * FROM director WHERE dempid='$regno' AND password='$pass' ";
	$rvwSearch ="SELECT * FROM reviewer WHERE reviewerid='$regno' AND password='$pass' ";
	$adminSearch ="SELECT * FROM admin WHERE empid='$regno' AND password='$pass' ";

//querys for searching research
	
	//research for student
	$std_research ="SELECT * FROM research WHERE regno='$regno'";

	//pending researches for staffs
	$dos_research_pd ="SELECT * FROM research WHERE dosempid is NULL";
	$dr_research_pd ="SELECT * FROM research WHERE dosempid is not NULL AND dempid is NULL";
	$rvw_research_pd ="SELECT * FROM `reviewer_research` RIGHT JOIN `research` ON `reviewer_research`.`researchid`=`research`.`researchid` WHERE `reviewer_research`.`reviewerid` != '$regno' OR `reviewer_research`.`reviewerid` is NULL AND `research`.dempid is NOT NULL"; 
	

	//reviewed researches for staffs
	$dos_research_rv ="SELECT * FROM research WHERE dosempid='$regno'";
	$dr_research_rv ="SELECT * FROM research WHERE dempid='$regno'";
	$rvw_research_rv ="SELECT * FROM `reviewer_research` RIGHT JOIN `research` ON `reviewer_research`.`researchid`=`research`.`researchid` WHERE `reviewer_research`.`reviewerid` = '$regno' AND `research`.dempid is NOT NULL"; 

//query of upload proposal file 
	$upload="INSERT INTO `research` (`researchid`, `title`, `abstract`, `file`, `regno`, `dempid`, `dosempid`) VALUES (NULL, '$title', '$abstr', '$filenameNew', '$regno', NULL, NULL)"; 

//query for submit comments

	$sendcommentdeofs="INSERT INTO `comment` (`commid`, `content`, `dosempid`, `dempid`,`researchid`,`reviewerid`) VALUES (NULL,'$comment', '$regno', NULL,'$rid',NULL)";
	$sendcommentdr="INSERT INTO `comment` (`commid`, `content`, `dosempid`, `dempid`,`researchid`,`reviewerid`) VALUES (NULL,'$comment', NULL, '$regno','$rid',NULL)";
	$sendcommentrv="INSERT INTO `comment` (`commid`, `content`, `dosempid`, `dempid`,`researchid`,`reviewerid`) VALUES (NULL,'$comment', NULL,NULL,'$rid','$regno')";
	
	//staff sign in researches
	$dfssign="UPDATE `research` SET `dosempid` = '$regno' WHERE `research`.`researchid` = $rid";
	$drsign="UPDATE `research` SET `dempid` = '$regno' WHERE `research`.`researchid` = $rid";
	$rvsign="INSERT INTO `reviewer_research` (`researchid`, `reviewerid`) VALUES ('$rid', '$regno');";

	//registration of customer in system
	$stdreg="INSERT INTO `customer` (`fullName`, `phoneNumber`, `location`,`password`) VALUES ('$fname', '$phon','$location', '$pass')";

} else {
	echo '<center >'.'sorry server is down, please wait'.'</center>';
}


?>