<!DOCTYPE html>
<html>

<head>
    <title>submit proposal</title>
    <link rel="stylesheet" type="text/css" href="main.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery-3.2.1.slim.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container-fluid ">
        
        <div class="row thumbnail" >
            <div class="well well-sm col-xs-12" style="border: 1px solid gray;">
                
                    <center><h4>ADD FOOD MENU</h4></center>
                
            </div>
            <div class="col-xs-12" style="border:1px solid gray; background-color: #eee;padding-top: 10px;">
               
            <form method="post" action="uploadFile.php" enctype="multipart/form-data">
           
           <div class="form-group">
                <label for="foodName" class="col-form-label">Food Name</label>
               <input type="text" name="foodName" class="form-control fo" id="foodName" placeholder="Enter name of food" required>
           </div>
          
           <div class="form-group">
               <label for="foodPrice" class=" col-form-label">Price of Food</label>
               <input type="text" name="foodPrice" class="form-control" id="foodPrice" placeholder="Enter price of food" required>
           </div>
           
            <div class="form-group">
                        <label for="file" class="col-form-label">upload photo of food</label>
                        <input type="file" class="form-control"  name="file" id="file-to-upload"/>
                    </div>
           <div class="form-group col-xs-2 col-xs-offset-9">
               <br>
               <input type="submit" name="addFoodMenu" class="btn btn-primary" id="submit" onclick=" return Validate()">
           <br>
           <br>
           </div>
       </form>
                </form>
            </div>
        </div>
    </div>
</body>

</html>