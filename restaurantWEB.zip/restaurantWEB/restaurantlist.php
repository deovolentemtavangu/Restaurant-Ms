
<!--display in content of pending proposal-->
<center><h2>List of Restaurant</h2></center>
<div class="panel panel-default">

        
        <?php
        
         //geting of session variable for identify users
          $status = $_SESSION["status"];
          $phoneNumber = $_SESSION["phoneNumber"];
          $userid = $_SESSION['userid'];

                 
        //database conectivite
           $conn=mysqli_connect("localhost","root","","online_restaurant_system");

           if (mysqli_connect_errno($conn)) {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
           }
         //list of all restaurant
         $restaurant ="SELECT * FROM restaurant";
         //list of restaurant of spesfic manager
         $managerResataurant = "SELECT * FROM restaurant WHERE managerID = $userid";
  

          //geting of results of querys excuted
          $results = mysqli_query($conn,$restaurant);
          $managerResult = mysqli_query($conn,$managerResataurant);

          
          //geting of numbers of rows in each table for spacific email and apsswords
         
          $numRestaurant = mysqli_num_rows($results);
          $managerNumRestaurant = mysqli_num_rows( $managerResult);
          
  //if user is manager
          if ($status === "manager") {
            if ($managerNumRestaurant>0) {

              ?>

                <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-6">
                              <?php echo "RESTAURANT NAME"; ?>
                          </div>
                          <div class="col-xs-6">
                              <?php echo "ACTION"; ?>
                          </div>
                      </div>
                  </div>
                <div class="panel-group">
              <?php while ($row = mysqli_fetch_assoc($managerResult)) {
                               
                  ?>
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-xs-6">
                              <?php echo $row['restaurantName']; ?>
                          </div>
                          <div class="col-xs-3">

                            <!--view button for display popup window-->
                            <a href="index.php?id=suplierList&flag=<?php echo $row['restaurantId']; ?>"> <button class="btn btn-info"> <span class="glyphicon glyphicon-edit"></span> Manage Suplier</button></a>

                          </div>
                          <div class="col-xs-3">

                            <!--view button for display popup window-->
                            <a href="index.php?id=foodMenu&flag=<?php echo $row['restaurantId']; ?>"> <button class="btn btn-info"> <span class="glyphicon glyphicon-edit"></span> Manage Food Menu</button></a>

                          </div>
                        </div>
                      </div>
                   </div>
 
              <?php  }?>
                  
                  </div>
                  <div class="panel-footer">@online restaurant management system</div>

              <?php  } else { ?>
                    
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row" >
                          <div class="col-xs-12">
                              <center><a href="#" class="glyphicon glyphicon-comment"> empty!!!, there is no restaurant registered</a></center>
                          </div>
                        </div>
                      </div>
                   </div>
            
            <?php }
            
          }

  //if user is customer
          elseif ($status === "customer") {
            if ($numRestaurant>0) {
              ?>

                <div class="panel-heading">
                <div class="row">
                          <div class="col-xs-5">
                              <?php echo "RESTAURANT NAME"; ?>
                          </div>
                          <div class="col-xs-5">
                              <?php echo "RESTAURANT LOCATION"; ?>
                          </div>
                          <div class="col-xs-2">

                          <?php echo "ACTION"; ?>
                          </div>
                        </div>
                </div>
                <div class="panel-group">
                <center> <h4><P></P></h4></center>

              <?php while ($row = mysqli_fetch_assoc($results)) {

                  ?>
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-xs-5">
                              <?php echo $row['restaurantName']; ?>
                          </div>
                          <div class="col-xs-5">
                              <?php echo $row['location']; ?>
                          </div>
                          <div class="col-xs-2">
                            <!--view food menu button--> 
                            <a href="index.php?id=foodMenu&flag=<?php echo $row['restaurantId']; ?>"> <button class="btn btn-info"  onclick="<?php  $sessionName ="restaurantid".$row['restaurantId'];   $_SESSION["$sessionName"] = $row['restaurantId']; 
                              ?>"> <span class="glyphicon glyphicon-envelope"></span> View Food Menu</button></a>

                          </div>
                        </div>
                      </div>
                   </div>
 
              <?php  }?>
                  
                  </div>
                  <div class="panel-footer">@online restaurant management system</div>

              <?php  } else { ?>
                    
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-xs-12">
                              <center><a href="#" class="glyphicon glyphicon-comment">empty!!!, there is no restaurant registered</a></center>
                          </div>
                        </div>
                      </div>
                   </div>
            
            <?php }
          }

          else {
            # code...
          }
          


          ?>

    
  
</div>

