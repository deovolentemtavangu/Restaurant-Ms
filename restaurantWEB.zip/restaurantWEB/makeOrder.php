
<!--display in content of pending proposal-->
<center><h2>Make Order</h2></center>
<div class="panel panel-default">

        
        <?php
        
         //geting of session variable for identify users
          $status = $_SESSION["status"];
          $phoneNumber = $_SESSION["phoneNumber"];
          $userid = $_SESSION['userid'];
          $restaurantid = $_SESSION['restaurantid1'];

                 
        //database conectivite
           $conn=mysqli_connect("localhost","root","","online_restaurant_system");

           if (mysqli_connect_errno($conn)) {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
           }
        
         //list of foodmenu of spesfic restaurant
         $foodorder = "SELECT * FROM foodorder WHERE customerID = $userid";
  

          //geting of results of querys excuted
          $results = mysqli_query($conn,$foodorder);
        

          
          //geting of numbers of rows in each table for spacific email and apsswords
         
          $numFoodOrder = mysqli_num_rows($results);
          
          ?>
 
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-xs-12">
                              <center><a href="#" class="glyphicon glyphicon-comment">on progress</a></center>
                          </div>
                        </div>
                      </div>
                   </div>
            

    
  
</div>

