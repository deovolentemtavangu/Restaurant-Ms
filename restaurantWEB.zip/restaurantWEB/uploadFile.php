<?php

//database conectivite
$con=mysqli_connect("localhost","root","","online_restaurant_system");

if (mysqli_connect_errno($con)) {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//validation of submit page
	if (isset($_POST['submit'])) {
		session_start();
$status = $_SESSION["status"];
		//for students proposal submition
if ($status==="manager") {
	$restaurantName=$_POST['restaurantName'];
		$restlocation=$_POST['restlocation'];
		$userid = $_SESSION["userid"];
	//including of database conectivite
	
		$file =	$_FILES['file'];
		$fileName =	$_FILES['file']['name'];
		$fileSize =	$_FILES['file']['size'];
		$fileTmp =	$_FILES['file']['tmp_name'];
		$fileError=	$_FILES['file']['error'];
		$fileType =	$_FILES['file']['type'];
		$fileExt=	explode('.', $fileName);
		$fileActualExt=strtolower(end($fileExt));
		$allowed =	array('jpg','npg','jpeg','pdf','doc','docx','png');

if (in_array($fileActualExt, $allowed)) {
	if ($fileError===0) {
			$filenameNew=uniqid('',true).".".$fileActualExt;
			$fileDestination = 'images/'.$filenameNew;
			//query of upload proposal file 
			$upload="INSERT INTO `restaurant` (`restaurantId`, `managerID`, `restaurantName`, `location`, `image`) VALUES (NULL, '$userid', '$restaurantName', '$restlocation','$filenameNew')"; 
			$result = mysqli_query($con,$upload)or die(mysqli_error($con));
			if ($result) {
				move_uploaded_file($fileTmp, $fileDestination);
				header("location:index.php");
			}	
	} else {

		echo "upload file feiled";
	}
		
}
else {
			$filenameNew="restaurant.png";
			$upload="INSERT INTO `restaurant` (`restaurantId`, `managerID`, `restaurantName`, `location`, `image`) VALUES (NULL, '$userid', '$restaurantName', '$restlocation','$filenameNew')"; 
			$result = mysqli_query($con,$upload)or die(mysqli_error($con));
			if ($result) {
				header("location:index.php");
			}	
	}

} 
}
//end of submit page



//validation of submit page
if (isset($_POST['addFoodMenu'])) {
	session_start();
$status = $_SESSION["status"];
	//for students proposal submition
if ($status==="manager") {
	$foodName=$_POST['foodName'];
	$foodPrice=$_POST['foodPrice'];
	$restaurantid = $_SESSION["restaurantid"];
//including of database conectivite

	$file =	$_FILES['file'];
	$fileName =	$_FILES['file']['name'];
	$fileSize =	$_FILES['file']['size'];
	$fileTmp =	$_FILES['file']['tmp_name'];
	$fileError=	$_FILES['file']['error'];
	$fileType =	$_FILES['file']['type'];
	$fileExt=	explode('.', $fileName);
	$fileActualExt=strtolower(end($fileExt));
	$allowed =	array('jpg','npg','jpeg','pdf','doc','docx','png');

if (in_array($fileActualExt, $allowed)) {
if ($fileError===0) {
		$filenameNew=uniqid('',true).".".$fileActualExt;
		$fileDestination = 'images/'.$filenameNew;
		//query of upload proposal file 
		$upload="INSERT INTO `foodmanu` (`foodManuID`,`restaurantId`,`foodName`, `price`, `image`) VALUES (NULL, '$restaurantid', '$foodName', '$foodPrice','$filenameNew')"; 
		$result = mysqli_query($con,$upload)or die(mysqli_error($con));
		if ($result) {
			move_uploaded_file($fileTmp, $fileDestination);
			header("location:index.php?id=foodMenu&flag=$restaurantid");
		}	
} else {

	echo "upload file feiled";
}
	
}
else {
	$filenameNew="food.png";
	$upload="INSERT INTO `foodmanu` (`foodManuID`,`restaurantId`,`foodName`, `price`, `image`) VALUES (NULL, '$restaurantid', '$foodName', '$foodPrice','$filenameNew')"; 
	$result = mysqli_query($con,$upload)or die(mysqli_error($con));
		if ($result) {
			header("location:index.php?id=foodMenu&flag=$restaurantid");
		}	
}

} 
}
//end of submit page


?>