<img src="images/prof.png" class="img-thumbnail img-circle">
		<a href="index.php?id=restaurantlist"><span class="glyphicon glyphicon-edit"></span> Manage Restaurants</a>
		<a href="index.php?id=registerRestaurant"><span class="glyphicon glyphicon-pencil"></span> Register Restaurant</a>
		<a href="index.php?id=viewreport"><span class="glyphicon glyphicon-envelope"></span> View Report</a>
		<a href="index.php?id=editprofile"><span class="glyphicon glyphicon-edit"></span> Edit Profile</a>