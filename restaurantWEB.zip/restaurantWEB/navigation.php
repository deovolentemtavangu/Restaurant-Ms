
<?php
//page for navigation in a system when user use it

//chacking of login action post
if (isset($_POST['login'])) {
	$phoneNumber = $_POST['phoneNumber'];
	$password = $_POST['password'];
	

//database conectivite
	 $conn=mysqli_connect("localhost","root","","online_restaurant_system");

   if (mysqli_connect_errno($conn)) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }

//this is our sql query 
$sql = "SELECT * FROM `user` where `phonenumber`='$phoneNumber' and `password`='$password'";
 
//geting of results of querys excuted
$result = mysqli_query($conn,$sql);
 
//geting of numbers of rows for spacific email and apssword
$numberOfRow = mysqli_num_rows($result);
 
if ($numberOfRow>0) {
   $row = mysqli_fetch_assoc($result);
   if($row['status']== "customer")
   	{
   		$_SESSION["phoneNumber"]=$phoneNumber;
		$_SESSION["status"]=$row['status'];
		$_SESSION["userid"]=$row['id'];
		header('location:index.php');
   	}
   	elseif($row['status']== "manager")
   	{
   		$_SESSION["phoneNumber"]=$phoneNumber;
		$_SESSION["status"]=$row['status'];
		$_SESSION["userid"]=$row['id'];
		header('location:index.php');
   	}
	
} else {
		echo '<center>'.' Oops wrong password or email try again'.'</center>';;
}


}


//chacking of registration action post
if (isset($_POST['register'])) {


	$name  = $_POST['name'];
   $phoneNumber = $_POST['phoneNumber'];
   $location = $_POST['location'];
   $status = $_POST['status'];
   $password = $_POST['password'];

//database conectivite
	 $con=mysqli_connect("localhost","root","","online_restaurant_system") or die ("could not connect to mysql");

    if (mysqli_connect_errno($con)) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }
	
//this is our sql query 
$sql = "SELECT * FROM `user` where `phonenumber`='$phoneNumber'";
 
//geting of results of querys excuted
$result = mysqli_query($con,$sql);
 
//geting of numbers of rows for spacific phone number 
$numberOfRow = mysqli_num_rows($result);
 

  
//chacking of existance of user in system & identify table of user
	if ($numberOfRow>0) {
		echo '<center>'.'phone number is registered sorry use another number'.'</center>';
	}
	else {

		//insert data of user int data base

 $sql="INSERT INTO `user` (`id`,`fullname`, `phonenumber`, `password`, `location`,`status`) VALUES (NULL,'$name', '$phoneNumber','$password','$location','$status')";
   $query=mysqli_query($con,$sql)or die(mysqli_error($con));
		if ($query) {
			//this is our sql query 
			$sql1 = "SELECT * FROM `user` where `phonenumber`='$phoneNumber'";		
			//geting of results of querys excuted
			$result1 = mysqli_query($con,$sql1);
			$row = mysqli_fetch_assoc($result1);
			if ($result1) {
				$_SESSION["phoneNumber"]=$phoneNumber;
				$_SESSION["status"]=$status;
				$_SESSION["userid"]=$row['id'];
				header('location:index.php');
			}
		}
	}
}

//chacking of registerSupplier action post
if (isset($_POST['registerSuplier'])) {

	session_start();
	$name  = $_POST['suplierName'];
   $phoneNumber = $_POST['phoneNumber'];
   $location = $_POST['restlocation'];
   $restaurantid=$_SESSION["restaurantid"];

//database conectivite
	 $con=mysqli_connect("localhost","root","","online_restaurant_system") or die ("could not connect to mysql");

    if (mysqli_connect_errno($con)) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }
	
//this is our sql query 
$sql = "SELECT * FROM `user` where `phonenumber`='$phoneNumber'";
 
//geting of results of querys excuted
$result = mysqli_query($con,$sql);
 
//geting of numbers of rows for spacific phone number 
$numberOfRow = mysqli_num_rows($result);
 

  
//chacking of existance of user in system & identify table of user
	if ($numberOfRow>0) {
		echo '<center>'.'phone number is registered sorry use another number'.'</center>';
	}
	else {

		//insert data of user int data base

 $sql="INSERT INTO `user` (`id`,`fullname`, `phonenumber`, `password`,`location`,`restaurantId`,`status`) VALUES (NULL,'$name', '$phoneNumber','123','$location','$restaurantid','suplier')";
   $query=mysqli_query($con,$sql)or die(mysqli_error($con));
		if ($query) {
		header("location:index.php?id=suplierList&flag=$restaurantid");
		}
	}
}


//chacking of registerSupplier action post
if (isset($_POST['updateSuplier'])) {

	session_start();
	$name  = $_POST['suplierName'];
   $phoneNumber = $_POST['phoneNumber'];
   $location = $_POST['restlocation'];
   $id = $_POST['id'];
   $restaurantid=$_SESSION["restaurantid"];

//database conectivite
	 $con=mysqli_connect("localhost","root","","online_restaurant_system") or die ("could not connect to mysql");

    if (mysqli_connect_errno($con)) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
   }
	

		//insert data of user int data base

 $sql="UPDATE `user` SET  `fullname`= '$name' , `phonenumber` = '$phoneNumber' , `location` = '$location' WHERE `id` = $id";
   $query=mysqli_query($con,$sql)or die(mysqli_error($con));
		if ($query) {
		header("location:index.php?id=suplierList&flag=$restaurantid");
		}
	
}



 ?>
