
<!--display in content of pending proposal-->
<center><h2>list of suppliers</h2></center>
<div class="panel panel-default">

        
        <?php
        
         //geting of session variable for identify users
          $status = $_SESSION["status"];
          $phoneNumber = $_SESSION["phoneNumber"];
          $userid = $_SESSION['userid'];
          $restaurantid = "";
        
          if (isset($_GET['flag'])) {
            $restaurantid = intval($_GET['flag']);
            $_SESSION['restaurantid']=$restaurantid;
          }

                 
        //database conectivite
           $conn=mysqli_connect("localhost","root","","online_restaurant_system");

           if (mysqli_connect_errno($conn)) {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
           }
        
         //list of foodmenu of spesfic restaurant
         $foodmenu = "SELECT * FROM user WHERE restaurantId = $restaurantid";
  

          //geting of results of querys excuted
          $results = mysqli_query($conn,$foodmenu);
        

          
          //geting of numbers of rows in each table for spacific email and apsswords
         
          $numFoodMenu = mysqli_num_rows($results);
         
          if (isset($_GET['del'])) {
            if ($status === "manager") {
              $id = intval($_GET['del']);
              $delete = "DELETE FROM user WHERE id=$id";
              $resultdel = mysqli_query($conn,$delete);
             if ($resultdel) {
              header("location:index.php?id=suplierList&flag=$restaurantid");
             }
            }
          }
          
          //if user is manager
          if ($status === "manager") {
            if ($numFoodMenu>0) {

              ?>

                <div class="panel-heading">
                    <div class="row">
                          <div class="col-xs-3">
                              <?php echo "SUPLIER NAME"; ?>
                          </div>
                          <div class="col-xs-3">
                              <?php echo "PHONE NUMBER"; ?>
                          </div>
                          <div class="col-xs-6">

                          <?php echo "ACTION"; ?>
                          </div>
                    </div>
                </div>
                <div class="panel-group">
              <?php while ($row = mysqli_fetch_assoc( $results)) {
                               

                  ?>
                    <div class="panel panel-default">
                      <div class="panel-body">
                      <div class="row">
                          <div class="col-xs-3">
                              <?php echo $row['fullname']; ?>
                          </div>
                          <div class="col-xs-3">
                              <?php echo $row['phonenumber']; ?>
                          </div>
                          <div class="col-xs-3">

                            <!--edit menu button--> 
                            <a href="index.php?id=addSuplier&editsp=<?php echo $row['id']; ?>"> <button class="btn btn-info"> <span class="glyphicon glyphicon-edit"></span> edit supplier info</button></a>

                          </div>
                          <div class="col-xs-3">

                            <!--delete menu button--> 
                            <a href="index.php?id=suplierList&flag=<?php echo $row['restaurantId']; ?>&del=<?php echo $row['id']; ?>"> <button class="btn btn-danger"> <span class="glyphicon glyphicon-remove"></span> delete suplier</button></a>

                        </div>
                      </div>
                   </div>
                   </div>
              <?php  }?>
                  
                 </div>
                 

              <?php  } else { ?>
                    
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row" >
                          <div class="col-xs-12">
                              <center><a href="#" class="glyphicon glyphicon-comment"> sorry your not register any supplier in your restaurant, please register suplier</a></center>
                          </div>
                        </div>
                      </div>
                   </div>
            
            <?php }?>

<div class="panel-footer">
    <div class="row">
        <div class="col-xs-12" style="aling:right">

        <!--delete menu button--> 
        <a href="index.php?id=addSuplier"> <button class="btn btn-info"> <span class="glyphicon glyphicon-plus"></span> add suplier</button></a>

    </div>
    </div>
</div>
            
<?php }

  //if user is customer
          elseif ($status === "customer") {
            if ($numFoodMenu>0) {
              ?>

                <div class="panel-heading">
                <div class="row">
                          <div class="col-xs-5">
                              <?php echo "FOOD NAME"; ?>
                          </div>
                          <div class="col-xs-5">
                              <?php echo "FOOD PRICE"; ?>
                          </div>
                          <div class="col-xs-2">

                          <?php echo "ACTION"; ?>
                          </div>
                        </div>
                </div>
                <div class="panel-group">
                
              <?php while ($row = mysqli_fetch_assoc($results)) { ?>
                <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-xs-5">
                              <?php echo $row['foodName']; ?>
                          </div>
                          <div class="col-xs-5">
                              <?php echo $row['price']." Tsh"; ?>
                          </div>
                          <div class="col-xs-2">

                            <!--view make order button--> 
                            <a href="index.php?id=makeOrder"> <button class="btn btn-info"  onclick="<?php $_SESSION["foodManuID"] = $row['foodManuID']; 
                              ?>"> <span class="glyphicon glyphicon-pencil"></span> Make Order</button></a>

                          </div>
                        </div>
                      </div>
                   </div>
 
              <?php  }?>
                  
                  </div>
                  <div class="panel-footer">@online restaurant management system</div>

              <?php  } else { ?>
                    
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-xs-12">
                              <center><a href="#" class="glyphicon glyphicon-comment"><?php echo $restaurantid?>empty!!!, there is no food menu registered on this restaurant</a></center>
                          </div>
                        </div>
                      </div>
                   </div>
            
            <?php }
          }

          else {
            # code...
          }
          


          ?>

    
  
</div>

