<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<!--tages included in all pages-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
<body class="container-fluid">
<nav class="col-xs-12 nav navbar-default sticky-top" style="overflow:hidden;z-index:2;
">
	<div class="col-xs-12 navbar-header">
	<a class="navbar-brand" href="">ONLINE RESTAURANT SYSTEM</a>
	</div>

</nav>
<div class="row" style="padding-top: 100px">
	<div class="thumbnail col-xs-4 col-xs-offset-4" >
		<center><h2>LOGIN FORM</h2></center>

		<form class="col-xs-10 col-xs-offset-1" method="POST" action="login.php" style="padding: 20px">
			<div class="form-group">
					<label for="phoneNumber">phone Number</label>
					<input class="form-control" type="text" name="phoneNumber" id="phoneNumber" placeholder="enter your Phone Number" required>
			</div>

			<div class="form-group">
					<label for="password">password</label>
					<input class="form-control " type="password" name="password" id="password" placeholder="enter your password" required>
			</div>

<!--validation of login form when posted-->
		<?php
		session_start();
		include 'navigation.php';
		?>
		
			<button type="submit" name="login" class="btn btn-primary col-xs-8 col-xs-offset-2">login</button>
			<br>
			<br>
			<br>
			<center><a href="register.php" style="text-decoration: none;">if you don't have an account click here to register</a></center>
		</form>
		
	</div>
</div>
</body>
</html>