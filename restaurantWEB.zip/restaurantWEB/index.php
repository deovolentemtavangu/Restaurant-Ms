<?php
//for security
session_start();
if (empty($_SESSION['phoneNumber'])) {
	header('location:login.php');
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
<!--tages included in all pages-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="main.css">
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body class="container-fluid">

<!--navigationbar-->
<nav class="col-xs-12 nav navbar-default sticky-top" style="position:fixed;overflow:hidden;z-index:2;
">
	<div class="col-xs-12 navbar-header">
	<a class="navbar-brand" href="">ONLINE RESTAURANT SYSTEM</a>
	<a class="navbar-right 	glyphicon glyphicon-log-out" style="padding: 10px; text-decoration: none;" href="logout.php">LOGOUT</a>
	</div>

</nav>


<div class="container-fluid"  style="margin-top:60px;position:relative;" >
<div class="row">
<!--sidebar part-->
	<div class="col-xs-2 flex-xs-wrap-reverse  position-fixed">
	
		<div class="navbar-default sidebar-nav vertical-manu col-xs-12" style="height:650px;" >
		<?php
		require 'pagecontrol.php';
		require $leftcontent;
		?>
	</div>
	
	
	</div>	

<!--contents part-->
	<div class="col-xs-10 " style="">
		<div class="container-fluid">
			<?php 
			require 'pagecontrol.php';
			$restaurantid = "";
			require $content;
		 	?>
		</div>
	</div>
</div>
</div>


</body>
</html>