<!DOCTYPE html>
<html>

<head>
    <title>Registration</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body class="container-fluid">

<nav class="col-xs-12 nav navbar-default sticky-top" style="overflow:hidden;z-index:2;
">
    <div class="col-xs-12 navbar-header">
    <a class="navbar-brand" href="">ONLINE RESTAURANT SYSTEM</a>
    </div>
</nav>

    <div class="row" style="padding-top: 100px">
        <div class="thumbnail col-xs-6 col-xs-offset-3">
        <h2 style="text-align: center">REGISTRATION FORM</h2>
        <?php
        session_start();
        $comment="";
        include 'navigation.php';
        ?>
        <form action="register.php" method="POST" class="col-xs-10 col-xs-offset-1">
           
            <div class="form-group">
                 <label for="name" class="col-form-label">Full Name</label>
                <input type="text" name="name" class="form-control fo" id="name" placeholder="Enter your full name" required>
            </div>
           
            
           
            <div class="form-group">
                <label for="phoneNumber" class="col-form-label">Phone Number</label>
                <input type="text" name="phoneNumber" class="form-control" id="phoneNumber" placeholder="Eg  0716678117" pattern="[0-9]{4}[0-9]{3}[0-9]{3}" required>
            </div>
            
            <div class="form-group">
                <label for="location" class=" col-form-label">Location</label>
                <input type="text" name="location" class="form-control" id="location" placeholder="Enter location" required>
            </div>

            <div class="form-group">
                <label for="status" class=" col-form-label">Choose Your Status (choose manager if you have Restaurant)</label>
                <select type="text" name="status" list=value class="form-control" id="location" placeholder="Enter location" required>
                <datalist>
                <option value="customer">customer</option>
                <option value="manager">manager</option>
                </datalist>
                </select>
            </div>
            
            <div class="form-group">
                <label for="password" class="col-form-label">password</label>
                <input type="text" name="password" class="form-control" id="password2" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Enter password" required>
            </div>
           
            <div class="form-group">
                 <label for="Confirm password" class="col-form-label">Confirm password</label>
                <input type="text"  class="form-control" id="Confirmpassword1" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Enter password"
                    placeholder="Enter password" required>
            </div>
            <div class="form-group col-xs-2 col-xs-offset-9">
                <br>
                <input type="submit" name="register" class="btn btn-primary" id="submit1" onclick=" return Validate()">
            <br>
            <br>
            </div>
        </form>
       
    </div>
</div>

<script>
          
            // confirm of password
            function Validate() {
                var password = document.getElementById("password2").value;
                var confirmPassword = document.getElementById("Confirmpassword1").value;
                if (password != confirmPassword) {
                    alert(" Your password and confirmation password do not match");
                    return false;
                }
                return true;
            }
        </script>
</body>

</html>