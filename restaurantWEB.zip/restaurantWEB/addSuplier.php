<!DOCTYPE html>
<html>

<head>
    <title>add supplier</title>
    <link rel="stylesheet" type="text/css" href="main.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/jquery-3.2.1.slim.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>

<body>
                    <?php
                    if (isset($_GET['editsp'])) {
                        $id = intval($_GET['editsp']);
                         //database conectivite
                        $conn=mysqli_connect("localhost","root","","online_restaurant_system");

                        if (mysqli_connect_errno($conn)) {
                            echo "Failed to connect to MySQL: " . mysqli_connect_error();
                        }

                        //list of foodmenu of spesfic restaurant
                        $edit = "SELECT * FROM user WHERE id = $id";

                        //geting of results of querys excuted
                        $results = mysqli_query($conn,$edit);
                        
                        //geting of numbers of rows affected
                        
                        $numedit = mysqli_num_rows($results);
                        if ($numedit>0) {
                            $row = mysqli_fetch_assoc( $results);?>
                            <div class="container-fluid ">
        
                            <div class="row thumbnail" >
                                <div class="well well-sm col-xs-12" style="border: 1px solid gray;">
                                    
                                        <center><h4>EDIT SUPLIER INFORMATION</h4></center>
                                    
                                </div>
                                <div class="col-xs-12" style="border:1px solid gray; background-color: #eee;padding-top: 10px;">
                                   
                                <form method="post" action="navigation.php" enctype="multipart/form-data">
                               <input name="id" value="<?php echo $row["id"] ?>" type="hidden">
                               <div class="form-group">
                                    <label for="suplierName" class="col-form-label">Full Name of Suplier</label>
                                   <input type="text" value="<?php echo $row["fullname"] ?>" name="suplierName" class="form-control fo" id="supliertName" placeholder="Enter name of suplier" required>
                               </div>
                              
                               <div class="form-group">
                                   <label for="restlocation" class=" col-form-label">Location of Suplier</label>
                                   <input type="text" value="<?php echo $row["location"] ?>" name="restlocation" class="form-control" id="restlocation" placeholder="Enter location of your restaurant" required>
                               </div>
                    
                               <div class="form-group">
                                    <label for="phoneNumber" class="col-form-label">Phone Number</label>
                                    <input type="text" value="<?php echo $row["phonenumber"] ?>" name="phoneNumber" class="form-control" id="phoneNumber" placeholder="Eg  0716678117" pattern="[0-9]{4}[0-9]{3}[0-9]{3}" required>
                                </div>
                               
                               <div class="form-group col-xs-2 col-xs-offset-9">
                                   <br>
                                   <input type="submit" value="Submit Changes" name="updateSuplier" class="btn btn-primary" id="updatesp" onclick=" return Validate()">
                               <br>
                               <br>
                               </div>
                           </form>
                                    </form>
                                </div>
                            </div>
                        </div>
                    
                        <?php }
                        
                    }else{?>

                <div class="container-fluid ">
                        
                        <div class="row thumbnail" >
                            <div class="well well-sm col-xs-12" style="border: 1px solid gray;">
                                
                                    <center><h4>REGISTER SUPLIER</h4></center>
                                
                            </div>
                            <div class="col-xs-12" style="border:1px solid gray; background-color: #eee;padding-top: 10px;">
                            
                            <form method="post" action="navigation.php" enctype="multipart/form-data">
                        
                        <div class="form-group">
                                <label for="suplierName" class="col-form-label">Full Name of Suplier</label>
                            <input type="text" name="suplierName" class="form-control fo" id="supliertName" placeholder="Enter name of suplier" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="restlocation" class=" col-form-label">Location of Suplier</label>
                            <input type="text" name="restlocation" class="form-control" id="restlocation" placeholder="Enter location of your restaurant" required>
                        </div>

                        <div class="form-group">
                                <label for="phoneNumber" class="col-form-label">Phone Number</label>
                                <input type="text" name="phoneNumber" class="form-control" id="phoneNumber" placeholder="Eg  0716678117" pattern="[0-9]{4}[0-9]{3}[0-9]{3}" required>
                            </div>
                        
                        <div class="form-group col-xs-2 col-xs-offset-9">
                            <br>
                            <input type="submit" name="registerSuplier" class="btn btn-primary" id="submit" onclick=" return Validate()">
                        <br>
                        <br>
                        </div>
                    </form>
                                </form>
                            </div>
                        </div>
                    </div>

                <?php
                    }

                    ?>
    
</body>

</html>