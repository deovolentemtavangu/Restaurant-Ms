
<!--display in content of pending proposal-->
<center><h2>Food Orders</h2></center>
<div class="panel panel-default">

        
        <?php
        
         //geting of session variable for identify users
          $status = $_SESSION["status"];
          $phoneNumber = $_SESSION["phoneNumber"];
          $userid = $_SESSION['userid'];
          $restaurantid = $_SESSION['restaurantid1'];

                 
        //database conectivite
           $conn=mysqli_connect("localhost","root","","online_restaurant_system");

           if (mysqli_connect_errno($conn)) {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
           }
        
         //list of foodmenu of spesfic restaurant
         $foodorder = "SELECT * FROM foodorder WHERE customerID = $userid";
  

          //geting of results of querys excuted
          $results = mysqli_query($conn,$foodorder);
        

          
          //geting of numbers of rows in each table for spacific email and apsswords
         
          $numFoodOrder = mysqli_num_rows($results);
          
  //if user is manager
          if ($status === "manager") {
            if ($numFoodOrder>0) {

              ?>

                <div class="panel-heading">list of your restaurant</div>
                <div class="panel-group">
              <?php while ($row = mysqli_fetch_assoc($managerResult)) {
                                $rid = $row['restaurantId'];
                                $flag = "pending"; 
                                $_SESSION["restaurantid"]=$rid;
                                //require 'popup.php';

                  ?>
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-xs-11">
                              <?php echo $row['restaurantName']; ?>
                          </div>
                          <div class="col-xs-1">

                            <!--view button for display popup window-->
                              <button class="btn btn-info" onclick="document.getElementById('<?php echo $row['restaurantId'];
                                $rid = $row['researchid']; 
                              ?>').style.display='block'">view</button>

                          </div>
                        </div>
                      </div>
                   </div>
 
              <?php  }?>
                  
                  </div>
                  <div class="panel-footer">@online restaurant management system</div>

              <?php  } else { ?>
                    
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row" >
                          <div class="col-xs-12">
                              <center><a href="#" class="glyphicon glyphicon-comment"> empty!!!, there is no restaurant registered</a></center>
                          </div>
                        </div>
                      </div>
                   </div>
            
            <?php }
            
          }

  //if user is customer
          elseif ($status === "customer") {
            if ($numFoodOrder>0) {
              ?>

                <div class="panel-heading">
                <div class="row">
                          <div class="col-xs-5">
                              <?php echo "FOOD NAME"; ?>
                          </div>
                          <div class="col-xs-5">
                              <?php echo "FOOD PRICE"; ?>
                          </div>
                          <div class="col-xs-2">

                          <?php echo "ACTION"; ?>
                          </div>
                        </div>
                </div>
                <div class="panel-group">

              <?php while ($row = mysqli_fetch_assoc($results)) { ?>
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-xs-5">
                              <?php echo $row['price']; ?>
                          </div>
                          <div class="col-xs-5">
                              <?php echo $row['price']; ?>
                          </div>
                          <div class="col-xs-2">

                            <!--view food menu button--> 
                            <a href="index.php?id=foodMenu"> <button class="btn btn-info"> <span class="glyphicon glyphicon-envelope"></span> buy food</button></a>

                          </div>
                        </div>
                      </div>
                   </div>
 
              <?php  }?>
                  
                  </div>
                  <div class="panel-footer">@online restaurant management system</div>

              <?php  } else { ?>
                    
                    <div class="panel panel-default">
                      <div class="panel-body">
                        <div class="row">
                          <div class="col-xs-12">
                              <center><a href="#" class="glyphicon glyphicon-comment"> empty!!!, there is no food order applied</a></center>
                          </div>
                        </div>
                      </div>
                   </div>
            
            <?php }
          }

          else {
            # code...
          }
          


          ?>

    
  
</div>

